export default function Materials() {
  return <></>;
}
